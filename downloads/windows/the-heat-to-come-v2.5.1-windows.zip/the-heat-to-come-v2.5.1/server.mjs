import fs from 'node:fs';
import http from 'node:http';
import path from 'node:path';
import crypto from 'node:crypto';
const root = import.meta.dirname;
const portText = process.env.THE_HEAT_TO_COME_PORT || '4277';
if (!/^\d+$/.test(portText) || +portText < 1024 || +portText > 65535) throw Error('Invalid port');
const port = +portText;
const state = path.join(root, '.local-state');
const token = crypto.randomBytes(32).toString('hex');
const headers = {'Cache-Control':'no-store','X-The-Heat-Version':'2.5.1','X-Content-Type-Options':'nosniff','Referrer-Policy':'no-referrer','X-Frame-Options':'DENY','Content-Security-Policy':"default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; font-src 'self'; media-src 'self'; connect-src 'self'; object-src 'none'; base-uri 'none'; form-action 'none'; frame-ancestors 'none'"};
const mime = {'.html':'text/html; charset=utf-8','.js':'text/javascript; charset=utf-8','.css':'text/css; charset=utf-8','.json':'application/json','.svg':'image/svg+xml','.png':'image/png','.ttf':'font/ttf','.woff2':'font/woff2','.mp3':'audio/mpeg','.pdf':'application/pdf','.md':'text/plain; charset=utf-8','.txt':'text/plain; charset=utf-8','.docx':'application/vnd.openxmlformats-officedocument.wordprocessingml.document','.xlsx':'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'};
const server = http.createServer((req,res) => {
  const send = (status, body, extra={}) => res.writeHead(status,{...headers,...extra}).end(body);
  if (req.headers.host !== `127.0.0.1:${port}`) return send(403,'Invalid host');
  if (req.url === '/__health' && req.method === 'GET') return send(200,'2.5.1',{'X-The-Heat-Instance':token});
  if (req.url === '/__stop') {
    if(req.method !== 'POST' || req.headers.origin || req.headers['x-the-heat-instance'] !== token) return send(403,'Forbidden');
    send(200,'Stopping'); server.close(); server.closeAllConnections(); return;
  }
  if (!['GET','HEAD'].includes(req.method)) return send(405,'Method not allowed',{Allow:'GET, HEAD'});
  try {
    const url = new URL(req.url,'http://127.0.0.1');
    const decoded = decodeURIComponent(url.pathname);
    const docs = decoded.startsWith('/DOCUMENTATION/');
    const base = path.join(root,docs ? 'DOCUMENTATION':'app');
    const rel = docs ? decoded.slice('/DOCUMENTATION/'.length) : decoded.replace(/^\/+/, '') || 'index.html';
    const file = path.resolve(base,rel);
    const containment = path.relative(base,file);
    if(containment.startsWith('..') || path.isAbsolute(containment) || !fs.existsSync(file) || !fs.statSync(file).isFile()) return send(404,'Not found');
    res.writeHead(200,{...headers,'Content-Type':mime[path.extname(file)] || 'application/octet-stream'});
    if(req.method === 'HEAD') res.end(); else fs.createReadStream(file).on('error',()=>res.destroy()).pipe(res);
  } catch {send(400,'Bad request');}
});
server.on('error',()=>{process.exitCode=1;});
server.listen(port,'127.0.0.1',()=>{
  fs.mkdirSync(state,{recursive:true});
  fs.writeFileSync(path.join(state,'instance.txt'),token);
  fs.writeFileSync(path.join(state,'pid.txt'),String(process.pid));
});
process.on('exit',()=>{
  try {if(fs.readFileSync(path.join(state,'instance.txt'),'utf8')===token){fs.unlinkSync(path.join(state,'instance.txt')); fs.unlinkSync(path.join(state,'pid.txt'));}} catch {}
});
