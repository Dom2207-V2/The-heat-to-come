Option Explicit
Dim fso, shell, env, root, port, tokenFile, stream, token, req
Set fso = CreateObject("Scripting.FileSystemObject")
Set shell = CreateObject("WScript.Shell")
Set env = shell.Environment("Process")
root = fso.GetParentFolderName(WScript.ScriptFullName)
port = env("THE_HEAT_TO_COME_PORT")
If port = "" Then port = "4277"
If Not IsNumeric(port) Then WScript.Quit 1
If CDbl(port) <> Fix(CDbl(port)) Or CDbl(port) < 1024 Or CDbl(port) > 65535 Then WScript.Quit 1
tokenFile = fso.BuildPath(root,".local-state\instance.txt")
If Not fso.FileExists(tokenFile) Then WScript.Quit 0
Set stream = fso.OpenTextFile(tokenFile,1)
token = Trim(stream.ReadAll): stream.Close
If Len(token) <> 64 Then WScript.Quit 1
On Error Resume Next
Set req = CreateObject("MSXML2.ServerXMLHTTP.6.0")
req.setTimeouts 1000,1000,1000,1000
req.Open "POST","http://127.0.0.1:" & port & "/__stop",False
req.setRequestHeader "X-The-Heat-Instance",token
req.Send
If Err.Number <> 0 Then WScript.Quit 1
If req.Status <> 200 Then WScript.Quit 1
WScript.Quit 0
