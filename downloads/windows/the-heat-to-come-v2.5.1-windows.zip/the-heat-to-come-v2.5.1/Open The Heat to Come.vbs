Option Explicit
Dim fso, shell, env, root, url, port, tokenFile, attempt, ignored
Set fso = CreateObject("Scripting.FileSystemObject")
Set shell = CreateObject("WScript.Shell")
Set env = shell.Environment("Process")
root = fso.GetParentFolderName(WScript.ScriptFullName)
port = env("THE_HEAT_TO_COME_PORT")
If port = "" Then port = "4277"
If Not IsNumeric(port) Then WScript.Quit 1
If CDbl(port) <> Fix(CDbl(port)) Or CDbl(port) < 1024 Or CDbl(port) > 65535 Then WScript.Quit 1
url = "http://127.0.0.1:" & port
tokenFile = fso.BuildPath(root, ".local-state\instance.txt")
If Not Ready() Then
  ignored = shell.Run(Quote(fso.BuildPath(root,"runtime\node.exe")) & " " & Quote(fso.BuildPath(root,"server.mjs")), 0, False)
  For attempt = 1 To 50
    WScript.Sleep 100
    If Ready() Then Exit For
  Next
End If
If Not Ready() Then
  If env("THE_HEAT_TO_COME_LAUNCHER_NO_BROWSER") <> "1" Then MsgBox "Cannot start the local game. Extract the complete ZIP into a writable folder. Close another copy using port 4277, then try again.",16,"The Heat to Come"
  WScript.Quit 1
End If
If env("THE_HEAT_TO_COME_LAUNCHER_NO_BROWSER") <> "1" Then ignored = shell.Run(url & "/", 1, False)
WScript.Quit 0
Function Quote(value): Quote = Chr(34) & value & Chr(34): End Function
Function Ready()
  Dim req, stream, token
  Ready = False
  On Error Resume Next
  If Not fso.FileExists(tokenFile) Then Exit Function
  Set stream = fso.OpenTextFile(tokenFile,1)
  token = Trim(stream.ReadAll): stream.Close
  Set req = CreateObject("MSXML2.ServerXMLHTTP.6.0")
  req.setTimeouts 500,500,500,500
  req.Open "GET",url & "/__health",False
  req.Send
  If Err.Number = 0 Then Ready = (req.Status = 200 And req.getResponseHeader("X-The-Heat-Version") = "2.5.1" And req.getResponseHeader("X-The-Heat-Instance") = token And Len(token) = 64)
  Err.Clear
  On Error GoTo 0
End Function
