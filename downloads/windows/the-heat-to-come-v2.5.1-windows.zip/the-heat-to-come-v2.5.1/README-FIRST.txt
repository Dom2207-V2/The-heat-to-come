THE HEAT TO COME 2.5.1 - WINDOWS LOCAL CANDIDATE

1. Extract the complete ZIP into a new writable folder with a short path,
   for example a folder named THC on your Desktop. Avoid deeply nested folders:
   Windows ZIP extraction can fail when the full file path becomes too long.
2. Double-click Open The Heat to Come.vbs. The browser opens automatically.
3. When finished, double-click Close The Heat to Come.vbs.

Windows x64 with Windows Script Host (VBScript), a modern browser and permission
to run the included Node.js v22.23.3 runtime are required. No Node installation,
administrator privileges, firewall changes or internet connection are needed.
The server listens only on 127.0.0.1:4277. One copy can use that port at a time.
Closing the browser does not stop the server: use the Close launcher.
If organisational policy disables VBScript, consult your administrator; this
package does not change policy. A missing/blocked launcher is not a game defect.
The package is a portable folder, not a signed installer. Keep all files together.

The launchers store temporary instance markers in .local-state. Close uses an
instance token; it never terminates a process merely because its PID matches.
Browser saves remain in your browser profile. Do not clear browser data unless
you intend to delete those saves. Export important runs before moving versions.

The complete approved dossier is in DOCUMENTATION/INDEX.md, with PDF/DOCX
editions, XLSX workbook and original Markdown. See DOCUMENTATION/governance
for licence, privacy, support, credits and third-party notices.
This is an educational simulator, not a forecast or operational decision tool.
Local distribution candidate; online deployment and physical mobile-device
compatibility are not claimed.
